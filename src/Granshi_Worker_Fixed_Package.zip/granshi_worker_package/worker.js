/**
 * Granshi CMS Worker v3.1
 * Cloudflare Workers + D1 + R2
 * Compatible with the table/column names used by the supplied v3 worker.
 * Required bindings: DB (D1), MEDIA (R2), ASSETS (assets binding)
 * Required secrets: SESSION_SECRET (32+ chars), SETUP_TOKEN (first setup only)
 * Optional secret: RESEND_API_KEY
 */

const enc = new TextEncoder();
const dec = new TextDecoder();
const DAY = 86400000;
const MAX_UPLOAD = 25 * 1024 * 1024;
const b64 = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const unb64 = (value) => {
  const s = String(value || "").replace(/-/g, "+").replace(/_/g, "/");
  return Uint8Array.from(atob(s + "=".repeat((4 - (s.length % 4)) % 4)), c => c.charCodeAt(0));
};
const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff", ...headers }
});
const fail = (message, status = 400) => json({ error: message }, status);
const now = () => new Date().toISOString();

async function hmac(secret, value) {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return b64(await crypto.subtle.sign("HMAC", key, enc.encode(value)));
}
async function passwordHash(password, salt = b64(crypto.getRandomValues(new Uint8Array(16)))) {
  const key = await crypto.subtle.importKey("raw", enc.encode(String(password)), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: unb64(salt), iterations: 210000, hash: "SHA-256" }, key, 256);
  return { salt, hash: b64(bits) };
}
async function verifyPassword(password, salt, expected) {
  const got = await passwordHash(password, salt);
  // Constant-time comparison of the encoded digest.
  const a = enc.encode(got.hash), b = enc.encode(String(expected || ""));
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}
function cookie(req, name) {
  const raw = req.headers.get("Cookie") || "";
  for (const part of raw.split(";")) {
    const i = part.indexOf("=");
    if (i < 0) continue;
    if (part.slice(0, i).trim() === name) {
      try { return decodeURIComponent(part.slice(i + 1).trim()); } catch { return ""; }
    }
  }
  return "";
}
async function sessionToken(env, email) {
  const payload = b64(enc.encode(JSON.stringify({ email, exp: Date.now() + 7 * DAY })));
  return `${payload}.${await hmac(env.SESSION_SECRET, payload)}`;
}
async function auth(req, env) {
  try {
    if (!env.SESSION_SECRET || String(env.SESSION_SECRET).length < 32) return null;
    const parts = cookie(req, "granshi_session").split(".");
    if (parts.length !== 2) return null;
    const [payload, signature] = parts;
    const expected = await hmac(env.SESSION_SECRET, payload);
    const a = enc.encode(signature), b = enc.encode(expected);
    if (a.length !== b.length) return null;
    let diff = 0;
    for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
    if (diff) return null;
    const data = JSON.parse(dec.decode(unb64(payload)));
    if (!data.email || !Number.isFinite(data.exp) || data.exp < Date.now()) return null;
    const admin = await env.DB.prepare("SELECT email FROM admins WHERE email=?").bind(data.email).first();
    return admin?.email || null;
  } catch { return null; }
}
const sessionCookie = token => `granshi_session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800`;
const clearCookie = "granshi_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0";
async function body(req) { try { return await req.json(); } catch { return {}; } }
function str(v, max = 5000) { return String(v ?? "").trim().slice(0, max); }
function escapeHtml(v) {
  return String(v ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function safeUrl(value) {
  const s = str(value, 2048);
  if (!s) return "";
  if (s.startsWith("/") && !s.startsWith("//")) return s;
  try {
    const u = new URL(s);
    return ["http:", "https:", "mailto:", "tel:"].includes(u.protocol) ? s : "";
  } catch { return ""; }
}
function slugify(value) {
  return str(value, 200).toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9-]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "").slice(0, 100);
}
function int(value, fallback = 0, min = 0, max = 1000000) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.trunc(n))) : fallback;
}
function parseJson(value, fallback = []) { try { return typeof value === "string" ? JSON.parse(value) : (value ?? fallback); } catch { return fallback; } }

// A deliberately small HTML allow-list for the optional HTML block. Script/style,
// event handlers, javascript: URLs, forms, embeds and unknown elements are removed.
function sanitizeHtml(input) {
  let html = String(input ?? "").slice(0, 50000);
  html = html.replace(/<!--[\s\S]*?-->/g, "");
  html = html.replace(/<(script|style|iframe|object|embed|form|input|button|textarea|select|svg|math)[^>]*>[\s\S]*?<\/\1\s*>/gi, "");
  html = html.replace(/<(script|style|iframe|object|embed|form|input|button|textarea|select|svg|math)\b[^>]*\/?\s*>/gi, "");
  const allowed = new Set(["p","br","hr","h1","h2","h3","h4","strong","b","em","i","u","s","ul","ol","li","blockquote","code","pre","a","img","div","span","section","article","table","thead","tbody","tr","th","td"]);
  return html.replace(/<\/?([a-z0-9-]+)\b([^>]*)>/gi, (whole, tagRaw, rawAttrs) => {
    const tag = tagRaw.toLowerCase();
    if (!allowed.has(tag)) return "";
    const closing = /^\s*\//.test(whole.slice(1));
    if (closing) return ["br", "hr", "img"].includes(tag) ? "" : `</${tag}>`;
    const attrs = [];
    const re = /([a-zA-Z-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/g;
    let m;
    while ((m = re.exec(rawAttrs))) {
      const name = m[1].toLowerCase();
      const value = m[2] ?? m[3] ?? m[4] ?? "";
      if (name === "class") attrs.push(`class="${escapeHtml(value.slice(0, 120))}"`);
      if (name === "title" || name === "alt") attrs.push(`${name}="${escapeHtml(value.slice(0, 300))}"`);
      if (name === "href" && tag === "a") { const u = safeUrl(value); if (u) attrs.push(`href="${escapeHtml(u)}" rel="noopener noreferrer"`); }
      if (name === "src" && tag === "img") { const u = safeUrl(value); if (u) attrs.push(`src="${escapeHtml(u)}" loading="lazy"`); }
    }
    return `<${tag}${attrs.length ? " " + attrs.join(" ") : ""}${["br","hr","img"].includes(tag) ? "/>" : ">"}`;
  });
}

async function getSettings(env) {
  const r = await env.DB.prepare("SELECT key,value FROM settings").all();
  return Object.fromEntries((r.results || []).map(x => [x.key, x.value]));
}
async function allPublic(env) {
  const [settings, pages, depts, menus, products, categories] = await Promise.all([
    getSettings(env),
    env.DB.prepare("SELECT slug,title_en,title_ne,description_en,description_ne,content,template,updated_at FROM pages WHERE published=1 ORDER BY sort_order,title_en").all(),
    env.DB.prepare("SELECT id,name_en,name_ne,description_en,description_ne,url,icon,email,image,sort_order FROM departments WHERE visible=1 ORDER BY sort_order").all(),
    env.DB.prepare("SELECT id,label_en,label_ne,url,parent_id,sort_order FROM menus WHERE visible=1 ORDER BY sort_order").all(),
    env.DB.prepare("SELECT id,name_en,name_ne,slug,price,compare_price,currency,image,status,featured FROM products WHERE status='published' ORDER BY sort_order,name_en LIMIT 50").all(),
    env.DB.prepare("SELECT id,name_en,name_ne,slug,image FROM categories WHERE visible=1 ORDER BY sort_order").all()
  ]);
  return { settings, pages: pages.results || [], departments: depts.results || [], menus: menus.results || [], products: products.results || [], categories: categories.results || [] };
}

function renderBlocks(content, settings = {}) {
  const blocks = Array.isArray(parseJson(content, [])) ? parseJson(content, []) : [];
  return blocks.map(b => {
    if (!b || typeof b !== "object") return "";
    const t = b.type;
    if (t === "heading") { const level = int(b.level, 2, 1, 4); return `<h${level} class="blk-h">${escapeHtml(b.text)}</h${level}>`; }
    if (t === "paragraph") return `<p class="blk-p">${escapeHtml(b.text).replace(/\n/g, "<br>")}</p>`;
    if (t === "image" && safeUrl(b.url)) return `<figure class="blk-img"><img src="${escapeHtml(safeUrl(b.url))}" alt="${escapeHtml(b.alt)}" loading="lazy">${b.caption ? `<figcaption>${escapeHtml(b.caption)}</figcaption>` : ""}</figure>`;
    if (t === "button" && safeUrl(b.url)) return `<p class="blk-btn"><a class="btn" href="${escapeHtml(safeUrl(b.url))}" ${b.newtab ? 'target="_blank" rel="noopener noreferrer"' : ""}>${escapeHtml(b.text || "Learn more")}</a></p>`;
    if (t === "html") return `<div class="blk-html">${sanitizeHtml(b.html)}</div>`;
    if (t === "spacer") return `<div class="blk-spacer" style="height:${int(b.height, 32, 0, 1000)}px"></div>`;
    if (t === "divider") return `<hr class="blk-hr">`;
    if (t === "quote") return `<blockquote class="blk-quote"><p>${escapeHtml(b.text)}</p>${b.cite ? `<cite>${escapeHtml(b.cite)}</cite>` : ""}</blockquote>`;
    if (t === "columns") { const cols = Array.isArray(b.columns) ? b.columns.slice(0, 4) : []; return `<div class="blk-cols" style="--cols:${Math.max(1, cols.length)}">${cols.map(c => `<div class="blk-col">${escapeHtml(c.text).replace(/\n/g,"<br>")}</div>`).join("")}</div>`; }
    if (t === "cards") { const cards = Array.isArray(b.cards) ? b.cards.slice(0, 20) : []; return `<div class="blk-cards">${cards.map(c => `<article class="blk-card">${c.icon ? `<div class="ico">${escapeHtml(c.icon)}</div>` : ""}${safeUrl(c.image) ? `<img src="${escapeHtml(safeUrl(c.image))}" alt="" loading="lazy">` : ""}<h3>${escapeHtml(c.title)}</h3><p>${escapeHtml(c.text)}</p>${safeUrl(c.url) ? `<a href="${escapeHtml(safeUrl(c.url))}">${escapeHtml(c.linktext || "→")}</a>` : ""}</article>`).join("")}</div>`; }
    if (t === "hero") { const img = safeUrl(b.image || settings.hero_image); return `<section class="blk-hero" ${img ? `style="background-image:url('${escapeHtml(img)}')"` : ""}><div class="blk-hero-inner"><h1>${escapeHtml(b.title)}</h1><p>${escapeHtml(b.subtitle)}</p>${safeUrl(b.button_url) ? `<a class="btn" href="${escapeHtml(safeUrl(b.button_url))}">${escapeHtml(b.button_text || "Explore")}</a>` : ""}</div></section>`; }
    if (t === "video" && safeUrl(b.url)) { const src = safeUrl(b.url); if (/^https:\/\/(www\.)?(youtube\.com|youtu\.be|player\.vimeo\.com|vimeo\.com)\//i.test(src)) return `<div class="blk-video"><iframe src="${escapeHtml(src)}" title="Video" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>`; return `<div class="blk-video"><video src="${escapeHtml(src)}" controls playsinline preload="metadata"></video></div>`; }
    return "";
  }).join("\n");
}
function pageChrome(title, desc, bodyHtml, settings, lang = "en") {
  const brand = settings.brand_name || "Granshi", primary = settings.primary_color || "#101a2c", accent = settings.accent_color || "#e5c77e";
  const heroImg = safeUrl(settings.hero_image);
  return `<!doctype html><html lang="${lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)} · ${escapeHtml(brand)}</title><meta name="description" content="${escapeHtml(desc || "")}"><meta property="og:title" content="${escapeHtml(title)}"><meta property="og:description" content="${escapeHtml(desc || "")}">${heroImg ? `<meta property="og:image" content="${escapeHtml(heroImg)}">` : ""}<meta name="theme-color" content="${escapeHtml(primary)}"><style>
:root{--navy:${escapeHtml(primary)};--gold:${escapeHtml(accent)};--paper:#f6f7fb;--ink:#172033;--muted:#667085}*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;color:var(--ink);background:var(--paper)}a{text-decoration:none;color:inherit}.wrap{width:min(960px,92%);margin:auto}header{position:sticky;top:0;z-index:5;background:var(--navy);color:#fff;border-bottom:1px solid #ffffff20}.nav{min-height:64px;display:flex;align-items:center;justify-content:space-between;gap:12px}.brand{display:flex;align-items:center;gap:10px;font-weight:900;letter-spacing:1px}.mark{border:2px solid var(--gold);border-radius:12px;width:38px;height:38px;display:grid;place-items:center;color:var(--gold)}.btn{display:inline-block;padding:12px 18px;border-radius:10px;font-weight:700;background:linear-gradient(135deg,#f3dfa9,var(--gold));color:#182235}.page-hero{background:var(--navy);color:#fff;padding:48px 0 36px}.page-hero h1{margin:0;font-size:clamp(28px,5vw,42px)}.page-hero p{color:#c7d0dc;margin:12px 0 0}article{padding:36px 0 60px}.blk-h{margin:28px 0 12px}.blk-p{line-height:1.75;color:#334}.blk-img{margin:24px 0}.blk-img img{max-width:100%;border-radius:12px;display:block}.blk-img figcaption{font-size:13px;color:var(--muted);margin-top:8px}.blk-quote{border-left:4px solid var(--gold);margin:24px 0;padding:8px 20px;background:#fff;border-radius:0 12px 12px 0}.blk-quote cite{display:block;margin-top:8px;font-size:13px;color:var(--muted)}.blk-hr{border:0;border-top:1px solid #e2e6ef;margin:28px 0}.blk-cols{display:grid;grid-template-columns:repeat(var(--cols,2),1fr);gap:20px;margin:20px 0}.blk-col{background:#fff;padding:18px;border-radius:12px;border:1px solid #e8ecf3;line-height:1.6}.blk-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;margin:20px 0}.blk-card{background:#fff;border:1px solid #e8ecf3;border-radius:14px;padding:18px}.blk-card img{width:100%;border-radius:10px;margin-bottom:10px}.blk-card h3{margin:0 0 6px;font-size:17px}.blk-card p{margin:0;color:var(--muted);font-size:14px}.blk-card a{display:inline-block;margin-top:10px;color:#8a6b2a;font-weight:700;font-size:13px}.blk-hero{min-height:320px;background-size:cover;background-position:center;color:#fff;display:flex;align-items:center;border-radius:16px;overflow:hidden;margin:12px 0 28px;position:relative;background-color:var(--navy)}.blk-hero:before{content:"";position:absolute;inset:0;background:linear-gradient(90deg,#101a2ce0,#101a2c66)}.blk-hero-inner{position:relative;padding:40px;max-width:640px}.blk-hero h1{margin:0 0 10px;font-size:clamp(26px,4vw,40px)}.blk-video{position:relative;padding-bottom:56.25%;height:0;margin:20px 0;border-radius:12px;overflow:hidden}.blk-video iframe,.blk-video video{position:absolute;inset:0;width:100%;height:100%;border:0}footer{background:var(--navy);color:#aab;padding:24px 0;font-size:14px;text-align:center}@media(max-width:700px){.blk-cols{grid-template-columns:1fr}.nav{min-height:58px}}
</style></head><body><header><div class="wrap nav"><a class="brand" href="/"><span class="mark">G</span><span>${escapeHtml(brand.toUpperCase())}</span></a><a class="btn" href="/">← Home</a></div></header>${bodyHtml}<footer><div class="wrap">${escapeHtml(settings.footer_text || "© Granshi")}</div></footer></body></html>`;
}
function renderPageHtml(page, settings, lang = "en") {
  const title = lang === "ne" && page.title_ne ? page.title_ne : page.title_en;
  const desc = lang === "ne" && page.description_ne ? page.description_ne : page.description_en || "";
  const html = `<section class="page-hero"><div class="wrap"><h1>${escapeHtml(title)}</h1>${desc ? `<p>${escapeHtml(desc)}</p>` : ""}</div></section><article class="wrap">${renderBlocks(page.content, settings)}</article>`;
  return pageChrome(title, desc, html, settings, lang);
}

async function sendEmail(env, { to, subject, html, replyTo, from }) {
  if (!env.RESEND_API_KEY || !to) return { sent: false, reason: !env.RESEND_API_KEY ? "email_service_not_configured" : "recipient_missing" };
  try {
    const res = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ from: from || "Granshi <noreply@gopalkoirala.com.np>", to: [to], subject, html, reply_to: replyTo || undefined }) });
    if (!res.ok) return { sent: false, reason: (await res.text()).slice(0, 1000) };
    return { sent: true };
  } catch (e) { return { sent: false, reason: String(e).slice(0, 500) }; }
}
function requireMethod(method, expected) { return method === expected; }
function idFromPath(path, prefix) { return decodeURIComponent(path.slice(prefix.length)).replace(/^\/+|\/+$/g, ""); }

async function api(req, env) {
  const url = new URL(req.url), p = url.pathname, method = req.method;
  if (p === "/api/health" && method === "GET") return json({ ok: true, service: "Granshi CMS v3.1", database: !!env.DB, media: !!env.MEDIA, assets: !!env.ASSETS, email: !!env.RESEND_API_KEY });
  if (p === "/api/public" && method === "GET") return json(await allPublic(env));

  if (p === "/api/contact" && method === "POST") {
    const x = await body(req), name = str(x.name, 120), email = str(x.email, 180).toLowerCase(), subject = str(x.subject, 200), msg = str(x.body || x.message, 5000);
    const departmentId = x.department_id ? int(x.department_id, 0, 1) : null;
    if (!name || !email || !msg) return fail("Name, email and message are required.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("Invalid email.");
    let deptEmail = null, deptName = null;
    if (departmentId) { const d = await env.DB.prepare("SELECT name_en,email FROM departments WHERE id=? AND visible=1").bind(departmentId).first(); if (d) { deptEmail = d.email || null; deptName = d.name_en; } }
    await env.DB.prepare("INSERT INTO messages(department_id,name,email,subject,body,status,created_at) VALUES(?,?,?,?,?,?,?)").bind(departmentId, name, email, subject || "Contact form", msg, "new", now()).run();
    const settings = await getSettings(env), target = deptEmail || settings.contact_email || null;
    const result = target ? await sendEmail(env, { to: target, subject: `[Granshi] ${subject || "New message"} — ${name}`, replyTo: email, html: `<p><b>From:</b> ${escapeHtml(name)} &lt;${escapeHtml(email)}&gt;</p><p><b>Department:</b> ${escapeHtml(deptName || "General")}</p><p><b>Subject:</b> ${escapeHtml(subject || "-")}</p><hr><p>${escapeHtml(msg).replace(/\n/g,"<br>")}</p>` }) : { sent: false };
    return json({ ok: true, emailed: result.sent, email_reason: result.sent ? undefined : result.reason || "recipient_not_configured" });
  }

  if (p === "/api/setup/status" && method === "GET") { const r = await env.DB.prepare("SELECT COUNT(*) AS n FROM admins").first(); return json({ initialized: Number(r?.n || 0) > 0 }); }
  if (p === "/api/setup" && method === "POST") {
    const x = await body(req), count = await env.DB.prepare("SELECT COUNT(*) AS n FROM admins").first();
    if (Number(count?.n || 0) > 0) return fail("Admin already initialized.", 409);
    if (!env.SETUP_TOKEN || !x.setupToken || x.setupToken !== env.SETUP_TOKEN) return fail("Invalid setup token.", 403);
    const email = str(x.email, 180).toLowerCase(), password = String(x.password || "");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 12) return fail("Valid email and password (12+ characters) required.");
    if (!env.SESSION_SECRET || String(env.SESSION_SECRET).length < 32) return fail("SESSION_SECRET must be configured with at least 32 characters.", 503);
    const h = await passwordHash(password);
    try { await env.DB.prepare("INSERT INTO admins(email,salt,password_hash,created_at) VALUES(?,?,?,?)").bind(email, h.salt, h.hash, now()).run(); }
    catch (e) { return fail("Admin setup failed. The admin may already exist.", 409); }
    return json({ ok: true }, 200, { "set-cookie": sessionCookie(await sessionToken(env, email)) });
  }
  if (p === "/api/auth/login" && method === "POST") {
    const x = await body(req), email = str(x.email, 180).toLowerCase();
    const a = await env.DB.prepare("SELECT email,salt,password_hash FROM admins WHERE email=?").bind(email).first();
    if (!a || !(await verifyPassword(String(x.password || ""), a.salt, a.password_hash))) return fail("Email or password incorrect.", 401);
    if (!env.SESSION_SECRET || String(env.SESSION_SECRET).length < 32) return fail("SESSION_SECRET is not configured correctly.", 503);
    return json({ ok: true }, 200, { "set-cookie": sessionCookie(await sessionToken(env, a.email)) });
  }
  if (p === "/api/auth/logout" && method === "POST") return json({ ok: true }, 200, { "set-cookie": clearCookie });

  const who = await auth(req, env);
  if (!who) return fail("Please log in.", 401);
  if (p === "/api/auth/me" && method === "GET") return json({ email: who });
  if (p === "/api/admin/overview" && method === "GET") {
    const [pub, msg, products] = await Promise.all([allPublic(env), env.DB.prepare("SELECT COUNT(*) AS n FROM messages WHERE status='new'").first(), env.DB.prepare("SELECT COUNT(*) AS n FROM products").first()]);
    return json({ email: who, new_messages: Number(msg?.n || 0), product_count: Number(products?.n || 0), ...pub });
  }

  // Pages: POST creates or updates by slug; DELETE removes the complete slug path.
  if (p === "/api/admin/pages" && method === "GET") return json((await env.DB.prepare("SELECT * FROM pages ORDER BY sort_order,updated_at DESC").all()).results || []);
  if (p === "/api/admin/pages" && method === "POST") {
    const x = await body(req), slug = slugify(x.slug || x.title_en), title = str(x.title_en, 250);
    if (!slug || !title) return fail("Title and valid slug are required.");
    const content = Array.isArray(x.content) ? x.content : parseJson(x.content, []);
    await env.DB.prepare(`INSERT INTO pages(slug,title_en,title_ne,description_en,description_ne,content,template,published,sort_order,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(slug) DO UPDATE SET title_en=excluded.title_en,title_ne=excluded.title_ne,description_en=excluded.description_en,description_ne=excluded.description_ne,content=excluded.content,template=excluded.template,published=excluded.published,sort_order=excluded.sort_order,updated_at=excluded.updated_at`).bind(slug, title, str(x.title_ne,250), str(x.description_en,1000), str(x.description_ne,1000), JSON.stringify(content), str(x.template || "default",50), x.published ? 1 : 0, int(x.sort_order), now()).run();
    return json({ ok: true, slug });
  }
  if (p.startsWith("/api/admin/pages/") && method === "DELETE") { const slug = idFromPath(p, "/api/admin/pages/"); if (!slug) return fail("Page slug required."); await env.DB.prepare("DELETE FROM pages WHERE slug=?").bind(slug).run(); return json({ ok: true }); }

  // Departments
  if (p === "/api/admin/departments" && method === "GET") return json((await env.DB.prepare("SELECT * FROM departments ORDER BY sort_order").all()).results || []);
  if (p === "/api/admin/departments" && method === "POST") {
    const x = await body(req), name = str(x.name_en,200), urlPath = str(x.url || "#",300);
    if (!name) return fail("Department English name is required.");
    const values = [name,str(x.name_ne,200),str(x.description_en,2000),str(x.description_ne,2000),urlPath,str(x.icon || "✦",30),str(x.email,180),safeUrl(x.image),x.visible === false ? 0 : 1,int(x.sort_order)];
    if (x.id) await env.DB.prepare("UPDATE departments SET name_en=?,name_ne=?,description_en=?,description_ne=?,url=?,icon=?,email=?,image=?,visible=?,sort_order=? WHERE id=?").bind(...values,int(x.id,0,1),).run();
    else await env.DB.prepare("INSERT INTO departments(name_en,name_ne,description_en,description_ne,url,icon,email,image,visible,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?)").bind(...values).run();
    return json({ ok: true });
  }
  if (p.startsWith("/api/admin/departments/") && method === "DELETE") { const id = int(idFromPath(p,"/api/admin/departments/"),0,1); if (!id) return fail("Invalid department ID."); await env.DB.prepare("DELETE FROM departments WHERE id=?").bind(id).run(); return json({ ok: true }); }

  // Menus
  if (p === "/api/admin/menus" && method === "GET") return json((await env.DB.prepare("SELECT * FROM menus ORDER BY sort_order").all()).results || []);
  if (p === "/api/admin/menus" && method === "POST") {
    const x = await body(req), label = str(x.label_en,200);
    if (!label) return fail("Menu English label is required.");
    const values = [label,str(x.label_ne,200),str(x.url || "#",500),x.parent_id ? int(x.parent_id,0,1) : null,x.visible === false ? 0 : 1,int(x.sort_order)];
    if (x.id) await env.DB.prepare("UPDATE menus SET label_en=?,label_ne=?,url=?,parent_id=?,visible=?,sort_order=? WHERE id=?").bind(...values,int(x.id,0,1)).run();
    else await env.DB.prepare("INSERT INTO menus(label_en,label_ne,url,parent_id,visible,sort_order) VALUES(?,?,?,?,?,?)").bind(...values).run();
    return json({ ok: true });
  }
  if (p.startsWith("/api/admin/menus/") && method === "DELETE") { const id = int(idFromPath(p,"/api/admin/menus/"),0,1); if (!id) return fail("Invalid menu ID."); await env.DB.prepare("DELETE FROM menus WHERE id=?").bind(id).run(); return json({ ok: true }); }

  // Settings
  if (p === "/api/admin/settings" && method === "GET") return json(await getSettings(env));
  if (p === "/api/admin/settings" && method === "POST") {
    const x = await body(req), allowed = new Set(["brand_name","primary_color","accent_color","hero_image","footer_text","contact_email","site_title","site_description"]);
    for (const [key,value] of Object.entries(x)) {
      if (!allowed.has(key)) continue;
      let v = str(value, key.includes("description") || key.includes("footer") ? 2000 : 500);
      if (key === "hero_image") v = safeUrl(v);
      if (["primary_color","accent_color"].includes(key) && !/^#[0-9a-fA-F]{3,8}$/.test(v)) return fail(`Invalid ${key}. Use a hex color.`);
      if (key === "contact_email" && v && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return fail("Invalid contact email.");
      await env.DB.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(key,v).run();
    }
    return json({ ok: true });
  }

  // Media: upload stores the R2 key; DELETE accepts nested key paths correctly.
  if (p === "/api/admin/media" && method === "GET") return json((await env.DB.prepare("SELECT * FROM media ORDER BY created_at DESC").all()).results || []);
  if (p === "/api/admin/media/upload" && method === "POST") {
    if (!env.MEDIA) return fail("R2 binding MEDIA is not configured.", 503);
    const file = await req.arrayBuffer(), type = str(req.headers.get("content-type") || "application/octet-stream",150).split(";")[0];
    if (!file.byteLength) return fail("Empty file.");
    if (file.byteLength > MAX_UPLOAD) return fail("Maximum upload size is 25 MB.", 413);
    const rawName = req.headers.get("x-file-name") || "upload.bin";
    let originalName = rawName; try { originalName = decodeURIComponent(rawName); } catch {}
    const name = originalName.split(/[\\/]/).pop().replace(/[^a-zA-Z0-9._-]/g,"_").slice(0,120) || "upload.bin";
    const key = `uploads/${crypto.randomUUID()}-${name}`;
    await env.MEDIA.put(key,file,{ httpMetadata:{ contentType:type } });
    const publicUrl = `/media/${key}`;
    try { await env.DB.prepare("INSERT INTO media(key,name,url,content_type,size,created_at) VALUES(?,?,?,?,?,?)").bind(key,name,publicUrl,type,file.byteLength,now()).run(); }
    catch (e) { await env.MEDIA.delete(key); throw e; }
    return json({ ok:true,key,url:publicUrl,name,size:file.byteLength });
  }
  if (p.startsWith("/api/admin/media/") && method === "DELETE") {
    const key = idFromPath(p,"/api/admin/media/");
    if (!key || key === "upload") return fail("Media key required.");
    if (env.MEDIA) await env.MEDIA.delete(key);
    await env.DB.prepare("DELETE FROM media WHERE key=?").bind(key).run();
    return json({ ok:true,key });
  }

  // Messages
  if (p === "/api/admin/messages" && method === "GET") return json((await env.DB.prepare("SELECT m.*,d.name_en AS department_name FROM messages m LEFT JOIN departments d ON d.id=m.department_id ORDER BY m.created_at DESC LIMIT 300").all()).results || []);
  if (p.startsWith("/api/admin/messages/") && method === "POST") {
    const id = int(idFromPath(p,"/api/admin/messages/"),0,1), x = await body(req);
    if (!id) return fail("Invalid message ID.");
    if (x.replyText !== undefined) {
      const replyText = str(x.replyText,5000);
      if (!replyText) return fail("Reply must be 1–5000 characters.");
      const message = await env.DB.prepare("SELECT id,name,email,subject FROM messages WHERE id=?").bind(id).first();
      if (!message?.email) return fail("Message or recipient email not found.",404);
      const sent = await sendEmail(env,{ to:message.email,from:"Granshi <info@gopalkoirala.com.np>",subject:`Re: ${str(message.subject || "Your message to Granshi",180)}`,html:`<p>Hello ${escapeHtml(message.name || "there")},</p><p>${escapeHtml(replyText).replace(/\n/g,"<br>")}</p><p>Regards,<br>Granshi</p>`,replyTo:"info@gopalkoirala.com.np" });
      if (!sent.sent) return json({ error:"Email could not be sent.",reason:sent.reason },502);
      await env.DB.prepare("UPDATE messages SET status='replied' WHERE id=?").bind(id).run();
      return json({ ok:true,replied:true });
    }
    if (x.status !== undefined) {
      const status = str(x.status,30);
      if (!["new","read","replied","archived"].includes(status)) return fail("Invalid message status.");
      await env.DB.prepare("UPDATE messages SET status=? WHERE id=?").bind(status,id).run();
    }
    return json({ ok:true });
  }
  if (p.startsWith("/api/admin/messages/") && method === "DELETE") { const id = int(idFromPath(p,"/api/admin/messages/"),0,1); if (!id) return fail("Invalid message ID."); await env.DB.prepare("DELETE FROM messages WHERE id=?").bind(id).run(); return json({ ok:true }); }

  // Password change
  if (p === "/api/admin/password" && method === "POST") {
    const x = await body(req), next = String(x.newPassword || "");
    if (next.length < 12 || next.length > 200) return fail("New password must be 12–200 characters.");
    const old = await env.DB.prepare("SELECT salt,password_hash FROM admins WHERE email=?").bind(who).first();
    if (!old || !(await verifyPassword(String(x.currentPassword || ""),old.salt,old.password_hash))) return fail("Current password incorrect.",401);
    const h = await passwordHash(next);
    await env.DB.prepare("UPDATE admins SET salt=?,password_hash=? WHERE email=?").bind(h.salt,h.hash,who).run();
    return json({ ok:true },200,{ "set-cookie":clearCookie });
  }

  // Categories
  if (p === "/api/admin/categories" && method === "GET") return json((await env.DB.prepare("SELECT * FROM categories ORDER BY sort_order").all()).results || []);
  if (p === "/api/admin/categories" && method === "POST") {
    const x = await body(req), name = str(x.name_en,200), slug = slugify(x.slug || name);
    if (!name || !slug) return fail("Category name required.");
    const vals = [name,str(x.name_ne,200),slug,str(x.description_en,2000),str(x.description_ne,2000),safeUrl(x.image),x.parent_id ? int(x.parent_id,0,1) : null,x.visible === false ? 0 : 1,int(x.sort_order)];
    if (x.id) await env.DB.prepare("UPDATE categories SET name_en=?,name_ne=?,slug=?,description_en=?,description_ne=?,image=?,parent_id=?,visible=?,sort_order=? WHERE id=?").bind(...vals,int(x.id,0,1)).run();
    else await env.DB.prepare("INSERT INTO categories(name_en,name_ne,slug,description_en,description_ne,image,parent_id,visible,sort_order) VALUES(?,?,?,?,?,?,?,?,?)").bind(...vals).run();
    return json({ ok:true,slug });
  }
  if (p.startsWith("/api/admin/categories/") && method === "DELETE") { const id = int(idFromPath(p,"/api/admin/categories/"),0,1); if (!id) return fail("Invalid category ID."); await env.DB.prepare("DELETE FROM categories WHERE id=?").bind(id).run(); return json({ ok:true }); }

  // Products
  if (p === "/api/admin/products" && method === "GET") return json((await env.DB.prepare("SELECT * FROM products ORDER BY sort_order,updated_at DESC").all()).results || []);
  if (p === "/api/admin/products" && method === "POST") {
    const x = await body(req), name = str(x.name_en,200), slug = slugify(x.slug || name);
    if (!name || !slug) return fail("Product name required.");
    const price = Number(x.price ?? 0), compare = x.compare_price == null || x.compare_price === "" ? null : Number(x.compare_price);
    if (!Number.isFinite(price) || price < 0 || (compare !== null && (!Number.isFinite(compare) || compare < 0))) return fail("Invalid product price.");
    const status = ["draft","published","archived"].includes(x.status) ? x.status : "draft", stamp = now();
    const vals = [name,str(x.name_ne,200),slug,str(x.description_en,5000),str(x.description_ne,5000),price,compare,str(x.currency || "NPR",8),safeUrl(x.image),JSON.stringify(Array.isArray(x.images) ? x.images.slice(0,20).map(safeUrl).filter(Boolean) : []),x.category_id ? int(x.category_id,0,1) : null,int(x.stock,0,0,100000000),str(x.sku,100),status,x.featured ? 1 : 0,int(x.sort_order)];
    if (x.id) await env.DB.prepare("UPDATE products SET name_en=?,name_ne=?,slug=?,description_en=?,description_ne=?,price=?,compare_price=?,currency=?,image=?,images=?,category_id=?,stock=?,sku=?,status=?,featured=?,sort_order=?,updated_at=? WHERE id=?").bind(...vals,stamp,int(x.id,0,1)).run();
    else await env.DB.prepare("INSERT INTO products(name_en,name_ne,slug,description_en,description_ne,price,compare_price,currency,image,images,category_id,stock,sku,status,featured,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").bind(...vals,stamp,stamp).run();
    return json({ ok:true,slug });
  }
  if (p.startsWith("/api/admin/products/") && method === "DELETE") { const id = int(idFromPath(p,"/api/admin/products/"),0,1); if (!id) return fail("Invalid product ID."); await env.DB.prepare("DELETE FROM products WHERE id=?").bind(id).run(); return json({ ok:true }); }

  // Orders
  if (p === "/api/admin/orders" && method === "GET") return json((await env.DB.prepare("SELECT * FROM orders ORDER BY created_at DESC LIMIT 200").all()).results || []);
  if (p.startsWith("/api/admin/orders/") && method === "POST") {
    const id = int(idFromPath(p,"/api/admin/orders/"),0,1), x = await body(req);
    const status = str(x.status,30);
    if (!id || !["pending","paid","processing","shipped","completed","cancelled","refunded"].includes(status)) return fail("Invalid order ID or status.");
    await env.DB.prepare("UPDATE orders SET status=?,updated_at=? WHERE id=?").bind(status,now(),id).run();
    return json({ ok:true });
  }

  return fail("API route not found.",404);
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    try {
      if (!env.DB && url.pathname.startsWith("/api/")) return fail("D1 binding DB is not configured.",503);
      if (url.pathname.startsWith("/api/")) {
        try { return await api(req,env); }
        catch (e) { console.error("GRANSHI API ERROR:",e?.stack || e); return json({ error:"Server error", ...(env.DEBUG_ERRORS === "true" ? { detail:String(e?.message || e) } : {}) },500); }
      }
      if (url.pathname.startsWith("/media/")) {
        if (!env.MEDIA) return new Response("Media not configured",{status:503});
        const key = decodeURIComponent(url.pathname.slice("/media/".length));
        if (!key || key.includes("..")) return new Response("Not found",{status:404});
        const obj = await env.MEDIA.get(key);
        if (!obj) return new Response("Not found",{status:404});
        const headers = new Headers(); obj.writeHttpMetadata(headers); headers.set("etag",obj.httpEtag); headers.set("cache-control","public, max-age=86400"); headers.set("x-content-type-options","nosniff");
        return new Response(obj.body,{headers});
      }
      // Department pages
      if (url.pathname.startsWith("/department/")) {
        const path = url.pathname.replace(/\/$/, "");
        const dept = await env.DB.prepare("SELECT * FROM departments WHERE url=? AND visible=1").bind(path).first();
        if (dept) {
          const settings = await getSettings(env), lang = url.searchParams.get("lang") === "ne" ? "ne" : "en";
          const title = lang === "ne" && dept.name_ne ? dept.name_ne : dept.name_en;
          const desc = lang === "ne" && dept.description_ne ? dept.description_ne : dept.description_en || "";
          const bodyHtml = `<section class="page-hero"><div class="wrap"><h1>${escapeHtml(title)}</h1>${desc ? `<p>${escapeHtml(desc)}</p>` : ""}</div></section><article class="wrap">${safeUrl(dept.image) ? `<figure class="blk-img"><img src="${escapeHtml(safeUrl(dept.image))}" alt="${escapeHtml(title)}" loading="lazy"></figure>` : ""}${desc ? `<p class="blk-p">${escapeHtml(desc).replace(/\n/g,"<br>")}</p>` : ""}</article>`;
          return new Response(pageChrome(title,desc,bodyHtml,settings,lang),{headers:{"content-type":"text/html; charset=utf-8","cache-control":"public, max-age=60"}});
        }
      }
      // Published CMS pages and products
      if (url.pathname !== "/" && !url.pathname.startsWith("/admin") && !url.pathname.includes(".")) {
        const slug = decodeURIComponent(url.pathname.slice(1).replace(/\/$/, ""));
        if (slug) {
          const page = await env.DB.prepare("SELECT * FROM pages WHERE slug=? AND published=1").bind(slug).first();
          if (page) { const settings = await getSettings(env), lang = url.searchParams.get("lang") === "ne" ? "ne" : "en"; return new Response(renderPageHtml(page,settings,lang),{headers:{"content-type":"text/html; charset=utf-8","cache-control":"public, max-age=60"}}); }
          const product = await env.DB.prepare("SELECT * FROM products WHERE slug=? AND status='published'").bind(slug).first();
          if (product) {
            const settings = await getSettings(env), lang = url.searchParams.get("lang") === "ne" ? "ne" : "en", title = lang === "ne" && product.name_ne ? product.name_ne : product.name_en, desc = lang === "ne" && product.description_ne ? product.description_ne : product.description_en || "";
            const bodyHtml = `<section class="page-hero"><div class="wrap"><h1>${escapeHtml(title)}</h1><p style="font-size:22px;color:var(--gold);margin-top:12px">${escapeHtml(String(product.price))} ${escapeHtml(product.currency || "NPR")}</p>${desc ? `<p>${escapeHtml(desc)}</p>` : ""}</div></section><article class="wrap">${safeUrl(product.image) ? `<figure class="blk-img"><img src="${escapeHtml(safeUrl(product.image))}" alt="${escapeHtml(title)}"></figure>` : ""}${desc ? `<p class="blk-p">${escapeHtml(desc).replace(/\n/g,"<br>")}</p>` : ""}</article>`;
            return new Response(pageChrome(title,desc,bodyHtml,settings,lang),{headers:{"content-type":"text/html; charset=utf-8","cache-control":"public, max-age=60"}});
          }
        }
      }
      if (!env.ASSETS) return new Response("Static assets binding ASSETS is not configured.",{status:503});
      return env.ASSETS.fetch(req);
    } catch (e) {
      console.error("GRANSHI WORKER ERROR:",e?.stack || e);
      return new Response("Internal server error",{status:500,headers:{"content-type":"text/plain; charset=utf-8","cache-control":"no-store"}});
    }
  }
};
