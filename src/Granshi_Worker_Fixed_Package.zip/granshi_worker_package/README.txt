Granshi CMS Worker package

Contents:
- worker.js: Cloudflare Worker source

Required Cloudflare bindings:
- DB: D1 database binding
- MEDIA: R2 bucket binding
- ASSETS: static assets binding

Required Worker secrets/variables used by the source:
- SESSION_SECRET
- SETUP_TOKEN
- RESEND_API_KEY (optional; required for outbound email)

IMPORTANT:
This package contains the Worker source only. It does not include or migrate your D1 schema, Admin frontend, or static website assets. Back up your existing Worker and database before deploying. Verify the D1 tables/columns and bindings match your project before production use.
